#!/usr/bin/env python3
"""
Sector Signal OS — 靜態網頁發布腳本
將月報 Markdown 轉為 HTML，推送到 GitHub Pages

使用方式：
  python3 deploy.py              # 轉換所有報告並推送
  python3 deploy.py --dry-run    # 只轉換，不推送
"""

import os
import sys
import subprocess
import argparse
from pathlib import Path
from datetime import datetime

BASE_DIR    = Path(__file__).parent.parent
REPORTS_DIR = BASE_DIR / "output" / "reports"
SITE_DIR    = BASE_DIR / "output" / "site"


# ── Markdown → HTML 轉換（輕量版，不需要外部套件）──

def md_to_html(md: str, title: str) -> str:
    """將 Markdown 月報轉為獨立 HTML 頁面"""
    import re

    # 基本轉換
    html_body = md
    # 標題
    html_body = re.sub(r'^### (.+)$', r'<h3>\1</h3>', html_body, flags=re.MULTILINE)
    html_body = re.sub(r'^## (.+)$',  r'<h2>\1</h2>', html_body, flags=re.MULTILINE)
    html_body = re.sub(r'^# (.+)$',   r'<h1>\1</h1>', html_body, flags=re.MULTILINE)
    # 粗體
    html_body = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', html_body)
    # 勾選框
    html_body = re.sub(r'- \[ \]', '<li class="todo"><input type="checkbox" disabled>', html_body)
    html_body = re.sub(r'- \[x\]', '<li class="todo done"><input type="checkbox" checked disabled>', html_body)
    # 列表
    html_body = re.sub(r'^- (.+)$', r'<li>\1</li>', html_body, flags=re.MULTILINE)
    # 分隔線
    html_body = re.sub(r'^---+$', '<hr>', html_body, flags=re.MULTILINE)
    # 段落（空行換段）
    paragraphs = html_body.split('\n\n')
    html_body  = '\n\n'.join(
        f'<p>{p.strip()}</p>' if not p.strip().startswith('<') else p
        for p in paragraphs if p.strip()
    )

    return f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title} — 兩津投資</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, "Noto Sans TC", sans-serif; background: #f7f5ef; color: #1a1a18; max-width: 820px; margin: 0 auto; padding: 2rem 1.5rem; line-height: 1.75; }}
  h1 {{ font-size: 24px; font-weight: 700; margin: 2rem 0 0.5rem; border-bottom: 2px solid #1a1a18; padding-bottom: 0.5rem; }}
  h2 {{ font-size: 16px; font-weight: 400; color: #7a7a74; margin-bottom: 1.5rem; }}
  h3 {{ font-size: 17px; font-weight: 700; margin: 2rem 0 0.75rem; color: #8b2500; border-left: 3px solid #8b2500; padding-left: 0.75rem; }}
  p  {{ margin-bottom: 1rem; color: #3d3d39; font-size: 15px; }}
  strong {{ color: #1a1a18; }}
  li {{ margin: 0.4rem 0 0.4rem 1.5rem; font-size: 14px; color: #3d3d39; }}
  li.todo {{ list-style: none; margin-left: 0; }}
  li.done {{ opacity: 0.5; }}
  hr {{ border: none; border-top: 1px solid #e2dfd4; margin: 1.5rem 0; }}
  .back-link {{ display: inline-block; margin-bottom: 1.5rem; font-size: 13px; color: #7a7a74; text-decoration: none; }}
  .back-link:hover {{ color: #1a1a18; }}
  footer {{ margin-top: 3rem; padding-top: 1rem; border-top: 1px solid #e2dfd4; font-size: 12px; color: #b0afa8; }}
</style>
</head>
<body>
<a class="back-link" href="../index.html">← 回到月報清單</a>
{html_body}
<footer>兩津投資公司 內部使用 — 不構成投資建議</footer>
</body>
</html>"""


def convert_all_reports():
    """將所有 .md 報告轉為 .html"""
    converted = []
    report_html_dir = SITE_DIR / "reports"
    report_html_dir.mkdir(parents=True, exist_ok=True)

    for md_file in REPORTS_DIR.glob("*_report.md"):
        html_file = report_html_dir / md_file.name.replace(".md", ".html")
        parts     = md_file.stem.split("_", 1)
        title     = f"{parts[0]} {parts[1].replace('_', ' ')}" if len(parts) == 2 else md_file.stem

        with open(md_file, "r", encoding="utf-8") as f:
            md_content = f.read()

        html_content = md_to_html(md_content, title)
        with open(html_file, "w", encoding="utf-8") as f:
            f.write(html_content)

        converted.append(html_file)
        print(f"  ✓ 轉換：{html_file.name}")

    return converted


def push_to_github(dry_run: bool = False):
    """推送到 GitHub Pages"""
    # 確認在 git repo 中
    result = subprocess.run(
        ["git", "rev-parse", "--git-dir"],
        cwd=BASE_DIR, capture_output=True
    )
    if result.returncode != 0:
        print("  ⚠ 尚未初始化 git repo，請先執行：")
        print("    git init")
        print("    git remote add origin https://github.com/[你的帳號]/sector-signal-os.git")
        return

    if dry_run:
        print("  [dry-run] 跳過 git push")
        return

    cmds = [
        ["git", "add", "output/site/"],
        ["git", "commit", "-m", f"月報更新 {datetime.now().strftime('%Y-%m-%d')}"],
        ["git", "push", "origin", "main"],
    ]
    for cmd in cmds:
        r = subprocess.run(cmd, cwd=BASE_DIR, capture_output=True, text=True)
        if r.returncode == 0:
            print(f"  ✓ {' '.join(cmd[:2])}")
        else:
            print(f"  ✗ 失敗：{r.stderr[:150]}")
            break


def main():
    parser = argparse.ArgumentParser(description="Sector Signal OS — 發布腳本")
    parser.add_argument("--dry-run", action="store_true", help="只轉換，不推送 GitHub")
    args = parser.parse_args()

    print(f"\n{'═'*50}")
    print("  Sector Signal OS — 發布腳本")
    print(f"{'═'*50}\n")

    print("  步驟一：轉換 Markdown → HTML")
    converted = convert_all_reports()
    print(f"  共轉換 {len(converted)} 份報告\n")

    print("  步驟二：更新網站首頁索引")
    # 呼叫 run_report.py 的 --site 模式
    subprocess.run(
        [sys.executable, str(BASE_DIR / "scripts" / "run_report.py"), "--site"],
        cwd=BASE_DIR
    )

    print("\n  步驟三：推送到 GitHub Pages")
    push_to_github(dry_run=args.dry_run)

    print(f"\n{'═'*50}")
    print(f"  完成！網站檔案：{SITE_DIR}")
    if not args.dry_run:
        print(f"  請確認 GitHub Pages 設定為 main branch / output/site 目錄")
    print(f"{'═'*50}\n")


if __name__ == "__main__":
    main()
