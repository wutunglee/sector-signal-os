#!/usr/bin/env python3
"""
Sector Signal OS — 主執行腳本
兩津投資公司

使用方式：
  python3 run_report.py                    # 執行所有「進行中」產業
  python3 run_report.py --sector "AI 伺服器供應鏈"   # 執行指定產業
  python3 run_report.py --preview          # 只顯示 Prompt，不執行
  python3 run_report.py --config path/to/custom.yaml
"""

import yaml
import argparse
import os
import sys
import json
import subprocess
from datetime import datetime
from pathlib import Path

# ── 路徑設定 ──
BASE_DIR   = Path(__file__).parent
CONFIG_DIR = BASE_DIR / "config"
OUTPUT_DIR = BASE_DIR / "output"
REPORTS_DIR = OUTPUT_DIR / "reports"
SITE_DIR   = OUTPUT_DIR / "site"

for d in [REPORTS_DIR, SITE_DIR]:
    d.mkdir(parents=True, exist_ok=True)


# ══════════════════════════════════════════════════════════════
# 設定檔載入
# ══════════════════════════════════════════════════════════════

def load_config(config_path: Path) -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# ══════════════════════════════════════════════════════════════
# Prompt 產生器
# ══════════════════════════════════════════════════════════════

def build_company_table(companies: list, market: str) -> str:
    if not companies:
        return ""
    lines = [f"  {market}觀察名單："]
    for c in companies:
        lines.append(f"    - {c['ticker']} {c['名稱']}（{c['層級']}層）")
    return "\n".join(lines)


def build_prompt(sector: dict, global_config: dict, month: str) -> str:
    name          = sector["名稱"]
    keywords      = sector.get("核心關鍵字", [])
    focus         = sector.get("額外聚焦", [])
    exclude       = sector.get("排除關鍵字", [])
    tw_stocks     = sector.get("台股觀察名單", [])
    us_stocks     = sector.get("美股觀察名單", [])
    note          = sector.get("備註", "")
    global_inst   = global_config.get("本月全域指示", [])
    noise_rules   = global_config.get("噪音過濾", [])
    search_days   = global_config.get("搜尋時間範圍", 30)
    max_signals   = global_config.get("每產業最多訊號數", 5)

    kw_str      = " ".join(keywords)
    focus_str   = "\n".join(f"  - {f}" for f in focus) if focus else "  （本月無額外聚焦）"
    exclude_str = "\n".join(f"  - {e}" for e in exclude) if exclude else "  （無）"
    global_str  = "\n".join(f"  - {i}" for i in global_inst)
    noise_str   = "\n".join(f"  - {r}" for r in noise_rules)
    tw_table    = build_company_table(tw_stocks, "台股")
    us_table    = build_company_table(us_stocks, "美股")
    note_str    = f"\n研究備註：{note}" if note else ""

    prompt = f"""/last30days {kw_str}

你是兩津投資公司的產業研究助理。
本月份：{month}
研究產業：{name}
搜尋時間範圍：過去 {search_days} 天

本月全域指示：
{global_str}

本月額外聚焦方向：
{focus_str}

請排除以下關鍵字相關的雜訊：
{exclude_str}

噪音過濾規則：
{noise_str}
{note_str}

候選公司觀察名單（請在報告中特別關注這些公司的相關訊號）：
{tw_table}
{us_table}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
請用繁體中文輸出，嚴格遵守以下結構：

# {name} Sector Signal Brief
## 兩津投資公司｜{month}

---

### 一、Executive Summary（執行摘要）
3–5 句段落，不要條列。

---

### 二、本月重要訊號（最多 {max_signals} 個）

每個訊號格式：
**[訊號標題]**
- 內容摘要：（2–3句）
- 訊號分類：需求增加／需求減弱／供給吃緊／供給過剩／價格變化／技術升級／資本支出／政策法規／地緣政治／競爭格局改變／市場敘事升溫／市場敘事降溫／財報或Guidance變化
- 產業鏈位置：上游／中游／下游／終端應用
- 影響方向：正面／負面／不確定
- 影響週期：短期（1–3個月）／中期（3–12個月）／長期（1年以上）
- 是否已有財報驗證：是／否／部分
- 股價反映程度：可能已充分反映／可能部分反映／可能尚未反映
- 來源：（來源名稱與日期）

---

### 三、產業鏈影響分析
上游／中游／下游／終端應用各一段。

---

### 四、候選公司池
從觀察名單中，依據本月訊號分配到 A／B／C 三層，並說明關聯理由與需要驗證的資料。
格式：表格，欄位：公司｜Ticker｜市場｜關聯理由｜需要驗證的資料

---

### 五、本月研究優先方向（3–5個）
每個方向：標題、核心問題、候選公司、需要驗證的資料、優先級（高／中／低）、建議負責人（留空）

---

### 六、To-Do List
分三欄：本月應查閱／本月應追蹤／下月應確認
每欄 3–5 個具體行動項目，用 [ ] 格式

---

### 七、團隊討論方向
5 個問題，不需要 AI 回答，留給月會討論。

---

### 八、噪音警示
2–3 個需要謹慎評估的訊號或市場敘事。

---

### 九、資料來源
所有引用來源，格式：序號｜來源名稱｜日期
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
    return prompt.strip()


# ══════════════════════════════════════════════════════════════
# 台灣在地訊號補充 Prompt
# ══════════════════════════════════════════════════════════════

def build_taiwan_supplement_prompt(sector: dict, month: str) -> str:
    name      = sector["名稱"]
    tw_stocks = sector.get("台股觀察名單", [])
    if not tw_stocks:
        return ""

    companies = "、".join(
        f"{c['ticker']} {c['名稱']}" for c in tw_stocks
    )

    return f"""
【台灣在地訊號補充 — {name}】
執行時機：每月 10–12 號（月營收公布後）

請搜尋以下台股公司過去 30 天的資訊：
公司清單：{companies}

請整理：
1. 月營收數字（與上月、去年同期比較，YoY / MoM）
2. 法說會或重大訊息摘要（如有）
3. TrendForce／集邦科技相關產業摘要（免費版）
4. 台灣財經媒體重要報導（鉅亨、MoneyDJ、旺得富）

輸出格式（每家公司一段，100–150字）：
- 公司名稱與月營收數字
- 訊號分類（同 Sector Signal Brief 標準）
- 與國際訊號的關聯或矛盾點
- 噪音風險提示

語言：繁體中文
""".strip()


# ══════════════════════════════════════════════════════════════
# 報告儲存
# ══════════════════════════════════════════════════════════════

def save_prompt(sector_name: str, prompt: str, month: str) -> Path:
    safe_name = sector_name.replace(" ", "_").replace("/", "-")
    filename  = f"{month}_{safe_name}_prompt.txt"
    path      = REPORTS_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        f.write(prompt)
    return path


def save_report(sector_name: str, content: str, month: str) -> Path:
    safe_name = sector_name.replace(" ", "_").replace("/", "-")
    filename  = f"{month}_{safe_name}_report.md"
    path      = REPORTS_DIR / filename
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)
    return path


# ══════════════════════════════════════════════════════════════
# 靜態網站產生器
# ══════════════════════════════════════════════════════════════

def generate_index_html(reports: list[dict]) -> str:
    """產生 GitHub Pages 首頁，含歷史月報清單與關鍵字搜尋"""
    report_items = ""
    for r in sorted(reports, key=lambda x: x["month"], reverse=True):
        report_items += f"""
        <div class="report-item" data-search="{r['sector']} {r['month']}">
          <span class="report-month">{r['month']}</span>
          <a href="{r['filename']}" class="report-title">{r['sector']}</a>
          <span class="report-badge badge-{r['priority']}">{r['priority']}</span>
        </div>"""

    return f"""<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>兩津投資 — Sector Signal Brief</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, "Noto Sans TC", sans-serif; background: #f7f5ef; color: #1a1a18; max-width: 800px; margin: 0 auto; padding: 2rem 1.5rem; }}
  header {{ border-bottom: 2px solid #1a1a18; padding-bottom: 1rem; margin-bottom: 2rem; }}
  .site-title {{ font-size: 22px; font-weight: 700; }}
  .site-sub {{ font-size: 13px; color: #7a7a74; margin-top: 4px; }}
  .search-bar {{ width: 100%; padding: 10px 14px; border: 1px solid #c8c5ba; background: white; font-size: 14px; margin-bottom: 1.5rem; border-radius: 4px; }}
  .search-bar:focus {{ outline: none; border-color: #1a1a18; }}
  .report-list {{ display: flex; flex-direction: column; gap: 8px; }}
  .report-item {{ display: flex; align-items: center; gap: 12px; padding: 12px 16px; background: white; border: 1px solid #e2dfd4; border-radius: 4px; }}
  .report-item.hidden {{ display: none; }}
  .report-month {{ font-family: monospace; font-size: 12px; color: #7a7a74; min-width: 70px; }}
  .report-title {{ font-size: 14px; color: #1a1a18; text-decoration: none; flex: 1; }}
  .report-title:hover {{ text-decoration: underline; }}
  .report-badge {{ font-size: 10px; padding: 2px 8px; border-radius: 2px; font-family: monospace; }}
  .badge-高 {{ background: #e8f3e8; color: #0f6e56; }}
  .badge-中 {{ background: #faf0d0; color: #7a5a00; }}
  .badge-低 {{ background: #f1efe8; color: #7a7a74; }}
  .no-results {{ text-align: center; color: #7a7a74; padding: 2rem; display: none; }}
  footer {{ margin-top: 3rem; font-size: 12px; color: #b0afa8; text-align: center; }}
</style>
</head>
<body>
<header>
  <div class="site-title">兩津投資公司</div>
  <div class="site-sub">Sector Signal Brief — 產業訊號月報</div>
</header>
<input class="search-bar" type="text" placeholder="搜尋月份或產業名稱..." id="search" oninput="filterReports(this.value)">
<div class="report-list" id="report-list">
  {report_items}
</div>
<div class="no-results" id="no-results">沒有符合的月報</div>
<footer>兩津投資公司 內部使用 — 不構成投資建議</footer>
<script>
function filterReports(q) {{
  const items = document.querySelectorAll('.report-item');
  const kw = q.toLowerCase();
  let visible = 0;
  items.forEach(item => {{
    const match = item.dataset.search.toLowerCase().includes(kw);
    item.classList.toggle('hidden', !match);
    if (match) visible++;
  }});
  document.getElementById('no-results').style.display = visible === 0 ? 'block' : 'none';
}}
</script>
</body>
</html>"""


def scan_existing_reports() -> list[dict]:
    """掃描已有的報告檔案，產生索引清單"""
    reports = []
    for f in REPORTS_DIR.glob("*_report.md"):
        parts = f.stem.split("_", 1)
        if len(parts) == 2:
            month, sector_raw = parts
            sector = sector_raw.replace("_", " ").replace("-", "/")
            reports.append({
                "month":    month,
                "sector":   sector,
                "filename": f"reports/{f.name.replace('.md', '.html')}",
                "priority": "中",
            })
    return reports


def update_site_index():
    reports = scan_existing_reports()
    html    = generate_index_html(reports)
    index_path = SITE_DIR / "index.html"
    with open(index_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"  ✓ 網站首頁已更新：{index_path}")


# ══════════════════════════════════════════════════════════════
# 主流程
# ══════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Sector Signal OS — 兩津投資公司")
    parser.add_argument("--config",  default=str(BASE_DIR / "config" / "research_config.yaml"))
    parser.add_argument("--sector",  default=None, help="指定產業名稱（預設執行所有進行中產業）")
    parser.add_argument("--preview", action="store_true", help="只顯示 Prompt，不執行")
    parser.add_argument("--taiwan",  action="store_true", help="同時產生台灣在地訊號補充 Prompt")
    parser.add_argument("--site",    action="store_true", help="只更新靜態網站首頁")
    args = parser.parse_args()

    config = load_config(Path(args.config))
    month  = config.get("月份", datetime.now().strftime("%Y-%m"))
    global_cfg = config.get("全域設定", {})
    sectors    = config.get("產業方向", [])

    print(f"\n{'═'*55}")
    print(f"  Sector Signal OS — 兩津投資公司")
    print(f"  月份：{month}")
    print(f"{'═'*55}\n")

    if args.site:
        update_site_index()
        return

    # 篩選要執行的產業
    active_sectors = [
        s for s in sectors
        if s.get("狀態") in ("進行中", "新增")
        and (args.sector is None or s["名稱"] == args.sector)
    ]

    if not active_sectors:
        print("  ⚠ 沒有找到符合條件的產業方向，請確認設定檔。")
        sys.exit(1)

    print(f"  找到 {len(active_sectors)} 個產業方向：")
    for s in active_sectors:
        print(f"    [{s['優先級']}] {s['名稱']}")
    print()

    for sector in active_sectors:
        name = sector["名稱"]
        print(f"  ▶ 處理中：{name}")

        # 產生主 Prompt
        prompt = build_prompt(sector, global_cfg, month)
        prompt_path = save_prompt(name, prompt, month)
        print(f"    ✓ Prompt 已儲存：{prompt_path.name}")

        if args.preview:
            print(f"\n{'─'*55}")
            print(f"  PROMPT PREVIEW — {name}")
            print(f"{'─'*55}")
            print(prompt[:800] + "\n  ... [截斷，完整內容見檔案]")
            print(f"{'─'*55}\n")
        else:
            # 實際執行：呼叫 Claude Code CLI
            print(f"    ⏳ 執行 last30days（約 5–8 分鐘）...")
            result = subprocess.run(
                ["claude", "--print", prompt],
                capture_output=True, text=True, timeout=600
            )
            if result.returncode == 0 and result.stdout.strip():
                report_content = result.stdout.strip()
                report_path    = save_report(name, report_content, month)
                print(f"    ✓ 報告已儲存：{report_path.name}")
            else:
                err = result.stderr[:200] if result.stderr else "（無錯誤訊息）"
                print(f"    ✗ 執行失敗：{err}")
                print(f"      請手動執行 Prompt：{prompt_path}")

        # 產生台灣在地訊號補充
        if args.taiwan:
            tw_prompt = build_taiwan_supplement_prompt(sector, month)
            if tw_prompt:
                tw_path = save_prompt(f"{name}_台灣補充", tw_prompt, month)
                print(f"    ✓ 台灣補充 Prompt：{tw_path.name}")
        print()

    # 更新網站首頁
    update_site_index()

    print(f"{'═'*55}")
    print(f"  完成！報告儲存於：{REPORTS_DIR}")
    print(f"  網站首頁：{SITE_DIR / 'index.html'}")
    print(f"{'═'*55}\n")


if __name__ == "__main__":
    main()
